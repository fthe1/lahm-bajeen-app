package com.lahmbajeen.game;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    private WebView web;
    private RewardedAd rewardedAd;

    // ===== معرّفات AdMob =====
    // هذه معرّفات تجريبية رسمية من Google (تعرض إعلانات تجريبية بأمان).
    // بدّلها بمعرّفاتك من حساب AdMob قبل النشر:
    //  - APPLICATION_ID في AndroidManifest.xml
    //  - REWARDED_ID هنا (وحدة إعلانية نوع Rewarded)
    private static final String REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final int REWARD_GEMS = 5;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            w.getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#2b1d14"));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setTextZoom(100);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return openExternal(req.getUrl().toString());
            }
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return openExternal(url);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        setContentView(web);
        hideBars();
        web.loadUrl("file:///android_asset/index.html");

        // تهيئة إعلانات Google وتحميل أول فيديو بمكافأة
        MobileAds.initialize(this, initializationStatus -> {});
        loadRewarded();
    }

    private void loadRewarded() {
        RewardedAd.load(this, REWARDED_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
                    @Override
                    public void onAdFailedToLoad(LoadAdError error) { rewardedAd = null; }
                });
    }

    private void grantReward() {
        if (web != null) {
            web.evaluateJavascript("try{onRewarded(" + REWARD_GEMS + ")}catch(e){}", null);
        }
    }

    private void toastJs(String msg) {
        if (web != null) {
            web.evaluateJavascript("try{toast('" + msg + "')}catch(e){}", null);
        }
    }

    /** جسر يستدعيه كود اللعبة: AndroidAds.showRewarded() */
    public class AdsBridge {
        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(() -> {
                if (rewardedAd != null) {
                    rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() { rewardedAd = null; loadRewarded(); }
                        @Override
                        public void onAdFailedToShowFullScreenContent(AdError e) { rewardedAd = null; loadRewarded(); }
                    });
                    rewardedAd.show(MainActivity.this, rewardItem -> grantReward());
                } else {
                    toastJs("الإعلان غير جاهز، حاول بعد لحظات");
                    loadRewarded();
                }
            });
        }
    }

    private boolean openExternal(String url) {
        if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) {}
            return true;
        }
        return false;
    }

    private void hideBars() {
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.evaluateJavascript("try{save()}catch(e){}", null);
            web.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // زر الرجوع: يفتح لوحة الإيقاف، وإذا كانت مفتوحة يغلقها
        web.evaluateJavascript("(function(){try{if(menuOn)return 'exit';var pn=document.getElementById('pn');if(pn&&pn.style.display=='flex'){closeP();return 'ok'}openP('p');return 'ok'}catch(e){return 'exit'}})()",
                v -> { if (v != null && v.contains("exit")) { moveTaskToBack(true); } });
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
